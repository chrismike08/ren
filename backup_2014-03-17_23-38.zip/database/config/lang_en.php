<?php
/*
* Start page
*/
$config['start_page'] = "1";

/*
* Your website's title, description and keywords
*/
$config['logo'] = "PT.PLN<span>  </span><strong>AREA BERAU</strong>";
$config['title'] = "Bank data OPI - website Kumpulan Data PLN Area Berau";
$config['description'] = "Bank Data PT.PLN Area Berau yang dibuat oleh team OPI Berau untuk menjembatani kesenjangan sosial dan untuk mempermudah mendapatkan data data laporan or pekerjaan di lingkungan kerja PT.PLN Area Berau";
$config['keywords'] = "Bank data,Jaringan,Pembangkitan,OPI,the berandals,PLN Berau,Transaksi energi,site OPI";
$config['slogan'] = "Electricity for a better Life - go The Berandals Team.....";
$config['foot_info'] = "Copyright © 2014 <a href='#'>Teamz OPI  - The Berandals</a>";
?>