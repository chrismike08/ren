<?php
setlocale( LC_CTYPE, 'pl_PL' );

/*
* Start page
*/
$config['start_page'] = "1";

/*
* Your website's title, description and keywords
*/
$config['logo'] = "Quick<span>.</span><strong>Cms</strong>";
$config['title'] = "Quick.Cms - szybki i prosty system zarządzania treścią";
$config['description'] = "Szybki i prosty system zarządzania treścią. Skrypt napisany w języku PHP, oparty o plikową bazę danych i zgodny ze standardami XHTML 1.1 i WAI.";
$config['keywords'] = "Quick.Cms,cms,content management system,simple,flat files,fast,php,easy,best,freeware,gpl,OpenSolution,free";
$config['slogan'] = "Szybki i prosty system zarządzania treścią";
$config['foot_info'] = "Copyright © 2014 <a href='http://opensolution.org/quick.cms,pl,10.html'>system cms</a>";
?>